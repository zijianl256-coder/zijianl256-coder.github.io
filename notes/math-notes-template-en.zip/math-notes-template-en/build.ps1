Set-Location $PSScriptRoot
latexmk -xelatex -interaction=nonstopmode -halt-on-error main.tex
exit $LASTEXITCODE
