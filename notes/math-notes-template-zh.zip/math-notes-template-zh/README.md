# 数学讲义模板 (中文版)

从当前《Gauge Theory on Four-Manifolds》提取的可复用模板, 含 F1 封面.

## 编译

安装完整的 TeX Live 或 MiKTeX, 使用 XeLaTeX. 在解压后的项目目录运行:

```text
latexmk -xelatex main.tex
```

也可运行 `build.ps1`, 或在编辑器中将默认编译器设为 XeLaTeX 并编译两遍.
`main.pdf` 是已编译的示例. 不需要 Python、原讲义、外部图片或原机绝对路径.

## 文件

- `main.tex`: 主文件, 控制前言、目录、章节、附录、参考文献的顺序.
- `config.tex`: 书名、作者、年份、封面文本及字号.
- `style.tex`: 页边距、章节标题、页眉、定理框、编号、F1 封面.
- `chapters/`: 示例正文与前言, 可直接替换为自己的内容.
- `references.tex`: 示例参考文献.
- `.latexmkrc`: 默认 XeLaTeX 设置.

## 编号和使用

此模板沿用原书的 article 层级: `\notesChapter` 内部使用 `\section`, 表示一章;
`\subsection` 表示一节, `\subsubsection` 表示节内小标题. 不使用 `\chapter`.
新增文件后在 `main.tex` 用 `\input{chapters/文件名}` 引入, 不需要手动设置章计数器.

陈述环境包括 definition, theorem, lemma, proposition, corollary, example,
remark, assumption, condition, conjecture, 它们的名称在中英文版分别本地化,
代码名称保持相同. 陈述共用 equation 计数器, 编号为 1.1.1, 1.1.2 等.
需要引用的公式推荐使用 `eqn` 环境, 编号为 (1.1.E1), 与陈述独立;
无需编号的公式使用 `\[...\]`. 原生 equation 环境仍可使用, 但它会占用陈述序号.
图按章.节.序号独立编号; 表保留原书的标准独立编号.
`\notesAppendix` 切换为附录 A, B 等. `\partpage{标题}` 可选用作部分分隔页.

## 封面与字体

F1 的炭灰底色、居中布局、暖白文字已用 LaTeX/TikZ 重建, 所有文本可编辑.
安装了 Baskerville Old Face 时, 封面拉丁文字使用该字体; 未安装时自动使用
TeX Live 内置的 TeX Gyre Termes. 封面无衬线文字使用 Arial, 缺失时用 TeX Gyre Heros.
未打包系统字体文件. 若希望与原书 F1 字形完全一致, 请在使用电脑上安装
Baskerville Old Face. 中文版使用 Fandol 中文字体, 随完整 TeX Live 提供.
英文正文为 Latin Modern, 数学字体和原书一致.

长书名可在 config.tex 中调整两行标题与字号. 风格参数集中于 style.tex.
两版均保留 2.5cm 左右边距、3cm 上下边距、双面页眉、右对齐章标题,
定义/定理浅灰框、直体陈述正文和独立公式编号. 中文版将章、附录、目录、
证明、图表与参考文献名称本地化, 示例采用英文半角标点.
